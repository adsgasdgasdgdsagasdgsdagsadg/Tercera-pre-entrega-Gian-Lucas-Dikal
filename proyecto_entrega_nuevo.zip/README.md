
# Proyecto Final - Django

Este proyecto es parte de la tercera pre-entrega del curso de Python en CoderHouse.

## Funcionalidades
- Agregar cursos mediante un formulario.
- Buscar cursos por camada.

## Requisitos
- Python 3.9 o superior.
- Django 4.0 o superior.

## Instalación
1. Clonar el repositorio:
   ```
   git clone <URL del repositorio>
   cd ProyectoFinal
   ```
2. Instalar dependencias:
   ```
   pip install -r requirements.txt
   ```
3. Ejecutar migraciones:
   ```
   python manage.py migrate
   ```
4. Iniciar el servidor:
   ```
   python manage.py runserver
   ```

## Uso
- Acceder a la ruta `/form/` para agregar cursos.
- Acceder a la ruta `/search/` para buscar cursos.
