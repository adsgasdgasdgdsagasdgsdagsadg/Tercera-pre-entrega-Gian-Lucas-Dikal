
from django.shortcuts import render, redirect
from .forms import CursoFormulario, ProfesorFormulario, EstudianteFormulario
from .models import Curso

def home(request):
    return render(request, 'AppCoder/home.html')

def curso_formulario(request):
    if request.method == 'POST':
        form = CursoFormulario(request.POST)
        if form.is_valid():
            form.save()
            return redirect('home')
    else:
        form = CursoFormulario()
    return render(request, 'AppCoder/formulario.html', {'form': form})

def buscar_curso(request):
    if request.method == 'GET' and 'camada' in request.GET:
        camada = request.GET['camada']
        cursos = Curso.objects.filter(camada=camada)
        return render(request, 'AppCoder/resultados_busqueda.html', {'cursos': cursos})
    return render(request, 'AppCoder/buscar_curso.html')
