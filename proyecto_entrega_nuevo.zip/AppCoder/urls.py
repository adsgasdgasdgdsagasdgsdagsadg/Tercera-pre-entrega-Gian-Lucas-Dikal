
from django.urls import path
from . import views

urlpatterns = [
    path('', views.home, name='home'),
    path('form/', views.curso_formulario, name='curso_formulario'),
    path('search/', views.buscar_curso, name='buscar_curso'),
]
