
from django import forms
from .models import Curso, Profesor, Estudiante

class CursoFormulario(forms.ModelForm):
    class Meta:
        model = Curso
        fields = '__all__'

class ProfesorFormulario(forms.ModelForm):
    class Meta:
        model = Profesor
        fields = '__all__'

class EstudianteFormulario(forms.ModelForm):
    class Meta:
        model = Estudiante
        fields = '__all__'
